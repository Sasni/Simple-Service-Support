<?php

function simple_service_support_zlecenia_stats_client ()  // Pokazywanie strony ze statystykami
{

    global $wpdb;
    $table_name = $wpdb->prefix . 'cte'; // tables prefix
    $all_brands = $wpdb->get_results("SELECT brand, COUNT(brand) AS liczba FROM $table_name GROUP BY brand ORDER BY COUNT(brand) DESC"); // Pytanie wypisujące markę oraz zaiczające je.

	echo '<div class="wrap">';?>
	
				<?php 
				foreach ($all_brands as $value): 
				$do_wykresu[] = "['".$value->brand."', ".$value->liczba."]";
				endforeach;  ?>
	
		<?php $data_for_chart = implode(",", $do_wykresu);   //oddziela wartości tablicy przecinkami - dane z pętli foreach  ?>

		<!-- WYKRES GOOGLE -->
		<script type="text/javascript" src="https://www.google.com/jsapi"></script>
	    <script type="text/javascript">

	      // Load the Visualization API and the piechart package.
	      google.load('visualization', '1.1', {'packages':['corechart']});

	      // Set a callback to run when the Google Visualization API is loaded.
	      google.setOnLoadCallback(drawChart);

	      // Callback that creates and populates a data table,
	      // instantiates the pie chart, passes in the data and
	      // draws it.
	      function drawChart() {

	        // Create the data table.
	        var data = new google.visualization.DataTable();
	        data.addColumn('string', 'Marka');   // dodawanie kolumny
	        data.addColumn('number', 'Ilość');
	        data.addRows([
	          <?php echo $data_for_chart; ?>
	        ]);

	        // Set chart options
	        var options = {
	                       'width':600,
	                       'height':500,
	                       tooltip:{text:'percentage'},
	                       'is3D': true
	                       };

	        // Instantiate and draw our chart, passing in some options.
	        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
	        chart.draw(data, options);
	      }
	    </script>
		<div id="piechart_3d"></div>
		<!-- KONIEC WYKRESU GOOGLE -->

	
	<div style="clear:both;"></div>

<?php

	echo '</div>';

}